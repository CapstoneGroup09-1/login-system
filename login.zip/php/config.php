﻿<?php
	//数据库配置文件
	define("HOST","localhost");
	define("USER","root");
	define("PASS","root");
	define("DBNAME","lianxi");//项目的数据库
